
	document.write("Hello World.<br>");
	document.write("My name is Mark");